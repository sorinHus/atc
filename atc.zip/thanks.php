<!DOCTYPE html>
<html lang="en">
<?php include "header.php"; ?> 
<body>

<?php include "sidebar.php"; ?>



<p><b>Your message was sent</b></p>

<p>Your message was successfully sent!
Thank you for contacting us, we will reply
to your inquiry as soon as possible!</p>


<?php include "footer.php"; ?>

	

  
    <script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.scrollUp.min.js"></script>
	<script src="js/price-range.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/main.js"></script>
</body>
</html>